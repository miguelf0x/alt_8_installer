#!/usr/bin/env bash


##############################################################################
#                              genconfig script    							             #
#                                                                            #
# This script is designed for configuring ARIADNA MIS installer for Linux OS #
#                                                                            #
##############################################################################


###############################################################################
# Variables                                                                   #
###############################################################################

username=''
ip_mount=''
username_share=''
password_share=''
domain=''
distr='AltLinux8'
icon_version=8  # 6 для Java 6, 8 для Java 8
url_java=''
name_db=''              #Название БД(обычно MED)
ip_base=''   #IP сервера с БД
oracle_version=''
postgre_sql=''		#При использовании указать версию 13.
java_home=''
msoffice=1  # не используется по умолчанию
long_bit=2  # 0 - true
install_log='install.log'

#Ссылка на клиенты Oracle, можно указать на локальный каталог(Опционально)
url_oracle_client_11='http://klokan.spb.ru/PUB/oraarch/ORACLE%20CLIENT/XP_WIN2003_client_32bit/oracle_client_x32.tar'
url_oracle_client_12='http://klokan.spb.ru/PUB/oraarch/ORACLE%20CLIENT/win32_12201_client.tar'
url_instant_client='http://klokan.spb.ru/PUB/oraarch/ORACLE%20CLIENT/instant_client19.tar'

#Ссылка на PostgreSQLODBC, можно указать на локальный каталог(Опционально)
url_postgre_sql='https://ftp.postgresql.org/pub/odbc/versions/msi/psqlodbc_13_01_0000-x86.zip'

libre_office_install_location='/usr/lib64/LibreOffice/'
libre_office_home='/usr/lib64/LibreOffice/program/classes/'

###############################################################################
# Functions                                                                   #
###############################################################################

function Get_Base_Info(){

    read -r -p "Введите имя пользователя Linux: " response
    username=$response

    while : ;
    do
      read -r -p "Введите IP-адрес сетевой папки: " response
      if [[ "$response" =~ ^(([1-9]?[0-9]|1[0-9][0-9]|2([0-4][0-9]|5[0-5]))\.){3}([1-9]?[0-9]|1[0-9][0-9]|2([0-4][0-9]|5[0-5]))$ ]];
      then
        break
      fi
    done
    ip_mount=$response

    read -r -p "Введите имя аккаунта с доступом к сетевой папке: " response
    username_share=$response

    read -r -p "Введите пароль от данного аккаунта: " response
    password_share=$response

    read -r -p "Введите доменное имя [при наличии]: " response
    domain=$response

}

##############################################################################

function Select_Java_Version(){

    if [[ $(getconf LONG_BIT) -eq 64 ]];
    then
        echo "System is longbit (x86_64)" >> $install_log
        longbit=0
        url_java="http://klokan.spb.ru/PUB/jre-8u301-linux-x64.tar.gz"
    else
        echo "System is shortbit (i586)" >> $install_log
        longbit=1
        url_java="http://klokan.spb.ru/PUB/jre-8u301-linux-i586.tar.gz"
    fi

    java_home='/opt/java/jre1.8.0_301'

}

##############################################################################

function Get_DB_Info(){

	echo "Допустимые версии Oracle Client:"
	echo "1. Oracle Client 12 [Рекомендуется]"
	echo "2. Oracle InstantClient [Работает с АРМ после обновления от 28.05.20]"
	echo "3. Oracle Client 11"

	while [[ $oracle_version = "" ]]
      do
          read -r -p "Введите порядковый номер необходимой версии: " response
          if [[ $response -eq 1 ]];
          then
              oracle_version='12'

              read -r -p "Использовать адрес для скачивания клиента Oracle по умолчанию? [д/Н] " response
          	  if [[ "$response" =~ ^([nN][oO]|[nN]|[нН][еЕ][тТ]|[нН])$ ]]
          	  then
          		    read -r -p "Введите URL или локальный каталог" response
                  url_oracle_client_12=response
          	  fi

          elif [[ $response -eq 2 ]];
          then

              oracle_version='InstantClient'

              read -r -p "Использовать адрес для скачивания клиента Oracle по умолчанию? [д/Н] " response
          	  if [[ "$response" =~ ^([nN][oO]|[nN]|[нН][еЕ][тТ]|[нН])$ ]]
          	  then
          		    read -r -p "Введите URL или локальный каталог" response
                  url_instant_client=response
          	  fi

          elif [[ $response -eq 3 ]];
          then

              oracle_version='11'

              read -r -p "Использовать адрес для скачивания клиента Oracle по умолчанию? [д/Н] " response
          	  if [[ "$response" =~ ^([nN][oO]|[nN]|[нН][еЕ][тТ]|[нН])$ ]]
          	  then
          		    read -r -p "Введите URL или локальный каталог" response
                  url_oracle_client_11=response
          	  fi

          else
  			      echo "Некорректный ввод."
  		    fi
      done

    read -r -p "Будет ли использоваться PostgreSQL [Работает с АРМ после обновления от 23.08.21]? [д/Н] " response
	  if [[ "$response" =~ ^([yY][eE][sS]|[yY]|[дД][аА]|[дД])$ ]]
	  then
		    postgre_sql='13'
        read -r -p "Использовать адрес для скачивания PostgreSQLODBC по умолчанию? [д/Н] " response
        if [[ "$response" =~ ^([nN][oO]|[nN]|[нН][еЕ][тТ]|[нН])$ ]]
        then
            read -r -p "Введите URL или локальный каталог" response
            url_postgre_sql=response
        fi
	  fi

    read -r -p "Для печати будет использоваться Microsoft Office? [д/Н] " response
    if [[ "$response" =~ ^([yY][eE][sS]|[yY]|[дД][аА]|[дД])$ ]]
    then
        msoffice=0
    fi

    while : ;
    do
      read -r -p "Введите IP-адрес БД: " response
      if [[ "$response" =~ ^(([1-9]?[0-9]|1[0-9][0-9]|2([0-4][0-9]|5[0-5]))\.){3}([1-9]?[0-9]|1[0-9][0-9]|2([0-4][0-9]|5[0-5]))$ ]];
      then
        break
      fi
    done
    ip_base=$response

    read -r -p "Введите имя БД: " response
    name_db=$response

}

##############################################################################

function Generate_Config(){

    echo "# Имя пользователя" > ./main.cfg
    echo "username=$username" >> ./main.cfg
    echo "" >> ./main.cfg
    echo "# IP-адрес общей папки" >> ./main.cfg
    echo "ip_mount=$ip_mount" >> ./main.cfg
    echo "# Имя пользователя с доступом к общей папке" >> ./main.cfg
    echo "username_share=$username_share" >> ./main.cfg
    echo "# Пароль пользователя с доступом к общей папке" >> ./main.cfg
    echo "password_share=$password_share" >> ./main.cfg
    echo "# Домен (при необходимости)" >> ./main.cfg
    echo "domain=$domain" >> ./main.cfg
    echo "" >> ./main.cfg
    echo "# Дистрибутив" >> ./main.cfg
    echo "distr=$distr" >> ./main.cfg
    echo "# Разрядность системы" >> ./main.cfg
    echo "longbit=$longbit" >> ./main.cfg
    echo "" >> ./main.cfg
    echo "# Версия ярлыков" >> ./main.cfg
    echo "icon_version=$icon_version" >> ./main.cfg
    echo "# URL для скачивания JRE" >> ./main.cfg
    echo "url_java=$url_java" >> ./main.cfg
    echo "# Имя БД" >> ./main.cfg
    echo "name_db=$name_db" >> ./main.cfg
    echo "# IP-адрес БД" >> ./main.cfg
    echo "ip_base=$ip_base" >> ./main.cfg
    echo "# Версия Oracle Client" >> ./main.cfg
    echo "oracle_version=$oracle_version" >> ./main.cfg
    echo "# Версия PostgreSQL" >> ./main.cfg
    echo "postgre_sql=$postgre_sql" >> ./main.cfg
    echo "# Домашний каталог JRE" >> ./main.cfg
    echo "java_home=$java_home" >> ./main.cfg
    echo "# Признак использования MS Office [0 - да]" >> ./main.cfg
    echo "msoffice=$msoffice" >> ./main.cfg
    echo "# Домашний каталог LibreOffice" >> ./main.cfg
    echo "libre_office_home=$libre_office_home" >> ./main.cfg
    echo "# Расположение LibreOffice" >> ./main.cfg
    echo "libre_office_install_location=$libre_office_install_location" >> ./main.cfg
    echo "# Конфиг создан $(date)" >> ./main.cfg

    if [[ -f main.cfg ]];
    then
        echo "main.cfg создан успешно"
        echo "main.cfg создан успешно" >> $install_log
    fi

}

##############################################################################

Get_Base_Info
Select_Java_Version
Get_DB_Info
Generate_Config
