#!/usr/bin/env bash


###############################################################################
# Functions                                                                   #
###############################################################################

function Mount_ARM(){

cd /home/$username/linux_installer_alt8

if [[ -d /mnt/ARM ]];
then
    echo 'Каталог /mnt/ARM уже существует' >> $log_file
else
		echo 'Создание каталога /mnt/ARM' >> $log_file
		mkdir /mnt/ARM
		if [[ $? -eq 0 ]];
    then
        echo 'Каталог /mnt/ARM создан' >> $log_file
    else
        echo 'Невозможно создать каталог /mnt/ARM' >> $log_file
    fi
fi

if [[ -d /mnt/ARM/APP ]];
then
    echo 'Каталог /mnt/ARM/APP уже монтирован' >> $log_file
else
    echo 'Монтирование каталога' >> $log_file
		if [[ $domain = '' ]];
    then
        mount -t cifs //$ip_mount/ARIADNA/ /mnt/ARM -o username=$username_share,rw,password=$password_share
		else
        mount -t cifs //$ip_mount/ARIADNA/ /mnt/ARM -o username=$username_share,rw,password=$password_share,domain=$domain
		fi
	  echo 'Каталог с АРМами монтирован в каталог /mnt/ARM' >> $log_file
fi

if [[ -f updater.sh ]];
then
    echo 'updater.sh уже существует' >> $log_file
else
		cd /home/$username
		echo 'Создание updater.sh' >> $log_file
		touch updater.sh
		echo 'Sh скрипт updater.sh создан' >> $log_file
fi

    {
      echo 'sleep 30'
      echo 'mount -t cifs //'$ip_mount'/ARIADNA/ /mnt/ARM -o username='$username_share',rw,password='$password_share''
      echo 'sleep 10'
      echo 'cp -a -u -f /mnt/ARM/APP/ /home/'$username'/.wine/drive_c/ARIADNA/APP'
      echo 'chown -R '$username':'$username' /home/'$username'/.wine/drive_c/ARIADNA/APP'
      echo 'chmod -R 777 /home/'$username'/.wine/drive_c/ARIADNA/APP'
      echo -e '\n'
    } > 'updater.sh'

}

###############################################################################

function Install_Java(){

cd /home/$username/linux_installer_alt8

#Java 8 Version x32
if [[ $url_java = 'http://klokan.spb.ru/PUB/jre-8u301-linux-i586.tar' ]];
then
    if [ -d /opt/java/jre1.8.0_301 ];
    then
        echo 'Каталог /opt/java/jre1.8.0_301 уже создан, JAVA установлена' >> $log_file
		else
        echo 'Создание каталога /opt/java' >> $log_file
        mkdir /opt/java
    fi

    if [ -f jre-8u301-linux-i586.tar ];
    then
		    echo 'Дистрибутив JAVA уже скачан' >> $log_file
    else
        echo 'Дистрибутива JAVA нет' >> $log_file
        echo 'Скачивание дистрибутива java' >> $log_file
				wget $url_java
    fi

    if [ -d /home/$username/jre1.8.0_301 ];
    then
		    echo 'JAVA Распакована'  >> $log_file
		else
        echo 'Разархивация JAVA'  >> $log_file
			  tar -xf /home/$username/linux_installer_alt8/jre-8u301-linux-i586.tar
			  echo 'Удаление jre-8u301-linux-i586.tar' >> $log_file
        rm -f jre-8u301-linux-i586.tar
    fi

    if [ -d /opt/java/jre1.8.0_301 ];
    then
		    echo 'Найдена JAVA в каталоге /opt/java/jre1.8.0_301' >> $log_file
    else
        echo 'Перемещение каталога /home/'$username'/linux_installer_alt8/jre1.8.0_301 в /opt/java/jre1.8.0_301' >> $log_file
        mv /home/$username/linux_installer_alt8/jre1.8.0_301 /opt/java/jre1.8.0_301
        echo 'Каталог перемещен'  >> $log_file
        echo 'Регистрация JAVA в PATH' >> $log_file
        export PATH=$PATH:/opt/java/jre1.8.0_301/bin/
        echo 'PATH зарегистрирован' >> $log_file
    fi
fi

#Java 8 Version x64
if [[ $url_java = 'http://klokan.spb.ru/PUB/jre-8u301-linux-x64.tar' ]];
then
    if [ -d /opt/java/jre1.8.0_301 ];
    then
        echo 'Каталог /opt/java/jre1.8.0_301 уже создан, JAVA установлена' >> $log_file
		else
        echo 'Создание каталога /opt/java' >> $log_file
        mkdir /opt/java
    fi

    if [ -f jre-8u301-linux-x64.tar ];
    then
		    echo 'Дистрибутив JAVA уже скачан' >> $log_file
    else
				echo 'Дистрибутива JAVA нет' >> $log_file
				echo 'Скачивание дистрибутива java' >> $log_file
				wget $url_java
    fi

    if [ -d /home/$username/jre1.8.0_301 ];
    then
		    echo 'JAVA Распакована'  >> $log_file
    else
        echo 'Разархивация JAVA'  >> $log_file
        tar -xf /home/$username/linux_installer_alt8/jre-8u301-linux-x64.tar
        echo 'Удаление jre-8u301-linux-x64.tar' >> $log_file
        rm -f jre-8u301-linux-x64.tar
    fi

    if [ -d /opt/java/jre1.8.0_301 ];
    then
		    echo 'Найдена JAVA в каталоге /opt/java/jre1.8.0_301' >> $log_file
    else
        echo 'Перемещение каталога /home/'$username'/linux_installer_alt8/jre1.8.0_301 в /opt/java/jre1.8.0_301' >> $log_file
        mv /home/$username/linux_installer_alt8/jre1.8.0_301 /opt/java/jre1.8.0_301
        echo 'Каталог перемещен'  >> $log_file
        echo 'Регистрация JAVA в PATH' >> $log_file
        export PATH=$PATH:/opt/java/jre1.8.0_301/bin/
        echo 'PATH зарегистрирован' >> $log_file
    fi
fi

}

###############################################################################

function Install_Wine() {

  	echo 'Установка wine, конфигурация AltLinux' >> $log_file
  	apt-get -y install \
	  libSDL2-devel \
	  libxslt-devel \
	  libxml2-devel \
	  libjpeg-devel \
	  liblcms2-devel \
	  libpng-devel \
	  libtiff-devel \
	  libgphoto2-devel \
	  libsane-devel \
	  libcups-devel \
	  libalsa-devel \
	  libgsm-devel \
	  libmpg123-devel \
	  libpulseaudio-devel \
	  libopenal-devel \
	  libGLU-devel \
	  libusb-devel \
	  libieee1284-devel  \
	  libkrb5-devel \
	  libv4l-devel \
	  libunixODBC-devel \
	  libnetapi-devel  \
	  libpcap-devel \
	  libgtk+3-devel \
	  libcairo-devel \
	  libva-devel \
	  libudev-devel \
	  udev  \
	  libdbus-devel \
	  libICE-devel  \
	  libSM-devel \
	  libxcb-devel \
	  libX11-devel \
	  libXau-devel \
	  libXaw-devel \
	  libXrandr-devel \
	  gstreamer-devel \
	  gst-plugins-devel \
	  libXext-devel \
	  libXfixes-devel \
	  libXfont-devel \
	  libXft-devel \
	  libXi-devel \
	  libXmu-devel \
	  libXpm-devel \
	  libXrender-devel \
	  libXres-devel  \
	  libXScrnSaver-devel \
	  libXinerama-devel \
	  libXt-devel \
	  libXxf86dga-devel  \
	  libXxf86misc-devel \
	  libXcomposite-devel \
	  libXxf86vm-devel \
	  libfontenc-devel \
	  libXdamage-devel \
	  libXvMC-devel \
	  libXcursor-devel \
	  libXevie-devel \
	  libldap-devel \
	  libgnutlsxx-devel \
	  libEGL-devel \
	  libGL-devel \
	  xorg-dri-swrast \
	  glsl-optimizer \
	  libGLU-devel \
	  libGLw-devel \
	  libXv-devel >> $log_file

	apt-get -y install \
		desktop-file-utils \
		perl-XML-Simple >> $log_file

	apt-get -y install \
	  glibc-pthread  \
	  glibc-nss \
	  i586-libSDL2-devel \
	  i586-libxslt-devel  \
	  i586-libxml2-devel \
	  i586-libjpeg-devel \
	  i586-liblcms2-devel \
	  i586-libpng-devel \
	  i586-libtiff-devel \
	  i586-libgphoto2-devel \
	  i586-libsane-devel  \
	  i586-libcups-devel \
	  i586-libalsa-devel \
	  i586-libgsm-devel \
	  i586-libmpg123-devel \
	  i586-libpulseaudio-devel \
	  i586-libopenal-devel  \
	  i586-libGLU-devel \
	  i586-libusb-devel \
	  i586-libieee1284-devel  \
	  i586-libkrb5-devel \
	  i586-libv4l-devel \
	  i586-libunixODBC-devel \
	  i586-libpcap-devel \
	  i586-libgtk+3-devel  \
	  i586-libcairo-devel \
	  i586-libva-devel \
	  i586-libudev-devel  \
	  i586-libdbus-devel \
	  i586-libICE-devel  \
	  i586-libSM-devel \
	  i586-libxcb-devel \
	  i586-libX11-devel \
	  i586-libXau-devel \
	  i586-libXaw-devel \
	  i586-libXrandr-devel \
	  i586-libXext-devel  \
	  i586-libXfixes-devel \
	  i586-libXfont-devel  \
	  i586-libXft-devel \
	  i586-libXi-devel \
	  i586-libXmu-devel \
	  i586-libXpm-devel \
	  i586-libXrender-devel \
	  i586-libXres-devel  \
	  i586-libXScrnSaver-devel \
	  i586-libXinerama-devel \
	  i586-libXt-devel \
	  i586-libXxf86dga-devel  \
	  i586-libXxf86misc-devel \
	  i586-libXcomposite-devel \
	  i586-libXxf86vm-devel \
	  i586-libfontenc-devel \
	  i586-libXdamage-devel \
	  i586-libXvMC-devel \
	  i586-libXcursor-devel  \
	  i586-libXevie-devel \
	  i586-libldap-devel \
	  i586-libgnutlsxx-devel \
	  i586-libEGL-devel \
	  i586-libGL-devel \
	  i586-libGLU-devel \
	  i586-libGLw-devel \
	  i586-xorg-dri-swrast \
	  i586-libXv-devel

	apt-get -y install i586-glibc-core >> $log_file
#	apt-get -y install gcc5-c++ gcc5-fortran glibc-core cmake >> $log_file
	apt-get -y install m4 bison flex build-environment >> $log_file
  apt-get -y install i586-wine

	echo 'Установка winetricks' >> $log_file
  wget http://klokan.spb.ru/PUB/new_linux_utils/winetricks
  mv winetricks /usr/bin/winetricks
  chmod +x /usr/bin/winetricks

}

###############################################################################

function Host_for_oracle_client() {
    echo '127.0.0.1	'$HOSTNAME' localhost' > /etc/hosts
}

###############################################################################

case $EUID in
   0) ;;
   *) echo "Требуется повышение привилегий - введите пароль root:"
      su root -c $0 "$@" ;;
esac

if [ $EUID == 0 ];
then

  ###############################################################################
  # Variables                                                                   #
  ###############################################################################

  username=''
  ip_mount=''
  username_share=''
  password_share=''
  domain=''

  #Варианты AltLinux8,AltLinux9,RedOS,AstraLinux,RosaLinux,Ubuntu,Centos8
  distr='AltLinux8'
  url_java=""

  source ./main.cfg

  log_file="install_root.log"

  ###############################################################################
  # Load CFG                                                                    #
  ###############################################################################


  if ! [ -f $log_file ];
  then
    touch $log_file
  fi

  Mount_ARM
  Install_Java
  Install_Wine
  Host_for_oracle_client

fi
